A Pen created at CodePen.io. You can find this one at https://codepen.io/Brian-Salcedo/pen/JXqbqr.

 This is a controller dualshock 4 with buttons I did in CSS3.